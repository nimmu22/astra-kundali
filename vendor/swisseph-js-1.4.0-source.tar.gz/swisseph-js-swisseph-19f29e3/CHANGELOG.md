# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.4.0] - 2026-09-28

### Added

- Local eclipse circumstances in `@swisseph/node` and `@swisseph/browser`: `solarEclipseWhere()`, `solarEclipseHow()`, `findNextSolarEclipseAt()`, `lunarEclipseHow()` and `findNextLunarEclipseAt()`, plus `horizontalCoordinates()` (`swe_azalt`) and `siderealTime()` (`swe_sidtime`). Azimuths are returned as compass bearings.
- `setTopocentric()` in `@swisseph/browser`.
- `@swisseph/core` holds the shared types (`GeoPosition`, `SolarEclipseWhere`, `LocalSolarEclipse`, `LocalLunarEclipse`, `HorizontalCoordinates` and their attributes), the `EclipseVisibility` flags, and the readers both packages use to fill them.
- Tests for the 2 August 2027 and 31 December 2028 eclipses against pyswisseph (`packages/node/tests/eclipses.test.ts`, `packages/browser/test/eclipses.html`).

### Fixed

- `findNextSolarEclipse()` and `findNextLunarEclipse()` (node and browser) read their contact times from the wrong slots of `tret` (off by one: the solar `partialBegin` was the moment of local apparent noon, and the lunar `partialBegin` was always 0). They now follow the Swiss Ephemeris layout.

## [1.3.1] - 2026-07-21

### Fixed

- Fixed npm installation of `@swisseph/node` and `@swisseph/browser` by publishing pnpm-packed tarballs with concrete `@swisseph/core` dependency versions.

### Added

- Added `getAyanamsaExUt()` to `@swisseph/node`, exposing `swe_get_ayanamsa_ex_ut` with explicit calculation flags and native error propagation.
- Added compatible `setSiderealMode()`, `getAyanamsa()`, and `getAyanamsaExUt()` methods to `@swisseph/browser`.
- Added regression coverage and API documentation for extended ayanamsa calculations.

## [1.0.2] - 2026-01-02

**Note:** This release only affects `@swisseph/browser`. The `@swisseph/node` and `@swisseph/core` packages remain unchanged.

### Fixed
- Fixed missing `FS` export in WASM build, enabling `loadStandardEphemeris()` and `loadEphemerisFiles()` to work properly
- Added error checking with clear message when FS is not available
- Fixed hardcoded `/dist/swisseph.wasm` path - now uses relative path that works automatically with all bundlers

### Added
- Enhanced test page (`test/calculations.html`) with:
  - "Load Swiss Ephemeris" button to load ephemeris files from CDN
  - Automatic test re-run after loading ephemeris files
  - "Re-run All Tests" button for manual test execution
  - Swiss Ephemeris vs Moshier comparison tests
  - Asteroid calculation tests (requires Swiss Ephemeris loaded)

### Changed
- Updated `build-wasm.sh` to export `FS` and `allocateUTF8` runtime methods
- Rebuilt WASM module with proper filesystem support using Emscripten SDK

## [1.0.0] - 2025-12-XX

### Added
- Initial release of Swiss Ephemeris JS monorepo
- `@swisseph/core`: Shared TypeScript types and enums
- `@swisseph/node`: Node.js native addon with bundled ephemeris files
- `@swisseph/browser`: WebAssembly browser version with Moshier ephemeris
- Modern TypeScript API with object returns and enums
- Support for planetary positions, house calculations, and eclipse predictions
- Comprehensive type definitions and IntelliSense support

[1.0.1]: https://github.com/swisseph-js/swisseph/compare/v1.0.0...v1.0.1
[1.0.0]: https://github.com/swisseph-js/swisseph/releases/tag/v1.0.0
