/**
 * Swiss Ephemeris for Browsers (WebAssembly) - Modern TypeScript API
 *
 * High-precision astronomical calculations in the browser using WebAssembly.
 * This module provides the same modern API as the Node.js version but runs
 * entirely in the browser with no server required.
 */

import {
  CalendarType,
  Planet,
  CelestialBody,
  HouseSystem,
  HousePoint,
  CalculationFlagInput,
  EclipseTypeFlagInput,
  PlanetaryPosition,
  HouseData,
  LunarEclipse,
  SolarEclipse,
  DateTime,
  ExtendedDateTime,
  normalizeFlags,
  normalizeEclipseTypes,
  LunarEclipseImpl,
  SolarEclipseImpl,
  DateTimeImpl,
  CalculationFlag,
  CommonCalculationFlags,
  GeoPosition,
  SolarEclipseAttributes,
  SolarEclipseWhere,
  LocalSolarEclipse,
  LunarEclipseAttributes,
  LocalLunarEclipse,
  HorizontalCoordinates,
  compassBearing,
  solarEclipseAttributes,
  lunarEclipseAttributes,
  localSolarEclipse,
  localLunarEclipse,
} from '@swisseph/core';

/**
 * Emscripten Module interface
 */
interface EmscriptenModule {
  cwrap: <T = any>(
    ident: string,
    returnType: string | null,
    argTypes: string[]
  ) => T;
  ccall: (
    ident: string,
    returnType: string | null,
    argTypes: string[],
    args: any[]
  ) => any;
  allocateUTF8: (str: string) => number;
  getValue: (ptr: number, type: string) => number;
  setValue: (ptr: number, value: number, type: string) => void;
  UTF8ToString: (ptr: number) => string;
  _malloc: (size: number) => number;
  _free: (ptr: number) => void;
  FS: {
    mkdir: (path: string) => void;
    writeFile: (path: string, data: Uint8Array) => void;
    readFile: (path: string) => Uint8Array;
    unlink: (path: string) => void;
  };
}

/**
 * WebAssembly Swiss Ephemeris module type
 */
interface SwissEphModule extends EmscriptenModule {
  // Additional module-specific properties can be added here
}

/**
 * Swiss Ephemeris for browsers
 *
 * This class provides access to Swiss Ephemeris calculations in the browser
 * using WebAssembly. It must be initialized before use.
 *
 * @example
 * import { SwissEphemeris, Planet, CalculationFlag } from './swisseph-browser.js';
 *
 * const swe = new SwissEphemeris();
 * await swe.init();
 *
 * const jd = swe.julianDay(2007, 3, 3);
 * const sun = swe.calculatePosition(jd, Planet.Sun);
 * console.log(`Sun: ${sun.longitude}°`);
 */
export class SwissEphemeris {
  private module: SwissEphModule | null = null;
  private ready: boolean = false;

  // Wrapped C functions
  private _julday!: (
    year: number,
    month: number,
    day: number,
    hour: number,
    gregflag: number
  ) => number;
  private _getPlanetName!: (ipl: number) => string;
  private _setSiderealMode!: (siderealMode: number, t0: number, ayanT0: number) => void;
  private _getAyanamsa!: (julianDay: number) => number;
  private _close!: () => void;
  private _version!: () => string;

  /**
   * Initialize the WebAssembly module
   *
   * This must be called before using any other methods.
   * The WASM file is automatically loaded from the same directory as the JS bundle.
   *
   * @param wasmPath - Optional custom path to swisseph.wasm file (for advanced use cases)
   *
   * @example
   * const swe = new SwissEphemeris();
   * await swe.init();
   * console.log(swe.version());
   */
  async init(wasmPath?: string): Promise<void> {
    if (this.ready) return;

    // Dynamically import the WASM module (built separately by build-wasm.sh)
    // @ts-expect-error - WASM module is generated at build time
    const SwissEphModuleImport = await import('./swisseph.js');
    // Emscripten with MODULARIZE=1 exports the function, but ES module import
    // may wrap it differently. Try default, then the import itself, then check if it's already a function
    let SwissEphModuleFactory: any;
    if (typeof SwissEphModuleImport.default === 'function') {
      SwissEphModuleFactory = SwissEphModuleImport.default;
    } else if (typeof SwissEphModuleImport === 'function') {
      SwissEphModuleFactory = SwissEphModuleImport;
    } else if (SwissEphModuleImport.default) {
      SwissEphModuleFactory = SwissEphModuleImport.default;
    } else {
      // Fallback: try to get the function from the module
      SwissEphModuleFactory = (SwissEphModuleImport as any).SwissEphModule || SwissEphModuleImport;
    }

    if (typeof SwissEphModuleFactory !== 'function') {
      throw new Error('Failed to load WASM module: SwissEphModule factory function not found');
    }

    // Configure the WASM module to locate files correctly
    // Default to 'swisseph.wasm' (same directory as JS) unless custom path provided
    let resolvedWasmPath = wasmPath;
    if (!resolvedWasmPath) {
      try {
        // @ts-ignore - Valid in browser environments
        resolvedWasmPath = new URL('./swisseph.wasm', import.meta.url).href;
      } catch (e) {
        resolvedWasmPath = 'swisseph.wasm';
      }
    }

    this.module = (await SwissEphModuleFactory({
      locateFile: (path: string, prefix?: string) => {
        // If this is the WASM file, use the custom path provided by the user
        if (path === 'swisseph.wasm') {
          return resolvedWasmPath!;
        }
        // For other files, use the prefix if provided, otherwise use the path as-is
        return prefix ? prefix + path : path;
      }
    })) as SwissEphModule;

    this._wrapFunctions();
    this.ready = true;
    console.log('Swiss Ephemeris WASM initialized:', this.version());
  }

  /**
   * Wrap C functions for easier calling
   */
  private _wrapFunctions(): void {
    const m = this.module!;

    this._julday = m.cwrap<typeof this._julday>(
      'swe_julday_wrap',
      'number',
      ['number', 'number', 'number', 'number', 'number']
    );

    this._getPlanetName = m.cwrap<typeof this._getPlanetName>(
      'swe_get_planet_name_wrap',
      'string',
      ['number']
    );

    this._setSiderealMode = m.cwrap<typeof this._setSiderealMode>(
      'swe_set_sid_mode_wrap',
      null,
      ['number', 'number', 'number']
    );

    this._getAyanamsa = m.cwrap<typeof this._getAyanamsa>(
      'swe_get_ayanamsa_ut_wrap',
      'number',
      ['number']
    );

    this._close = m.cwrap<typeof this._close>('swe_close_wrap', null, []);

    this._version = m.cwrap<typeof this._version>('swe_version_wrap', 'string', []);
  }

  /**
   * Check if the module is ready for use
   * @throws Error if not initialized
   */
  private _checkReady(): void {
    if (!this.ready) {
      throw new Error(
        'SwissEphemeris not initialized. Call await swe.init() first.'
      );
    }
  }

  /**
   * Get Swiss Ephemeris version string
   */
  version(): string {
    this._checkReady();
    return this._version();
  }

  /**
   * Set ephemeris file path
   *
   * Note: This is typically not used in the browser version as we use
   * the built-in Moshier ephemeris.
   *
   * @param path - Path to ephemeris files
   */
  setEphemerisPath(path: string): void {
    this._checkReady();
    const m = this.module!;
    const pathPtr = m.allocateUTF8(path || '');
    m.ccall('swe_set_ephe_path_wrap', null, ['number'], [pathPtr]);
    m._free(pathPtr);
  }

  /**
   * Load standard Swiss Ephemeris data files from jsDelivr CDN
   *
   * Simple one-line method to download standard ephemeris files (~2MB).
   * After loading, you can use CalculationFlag.SwissEphemeris for maximum precision.
   *
   * @example
   * // Simple: Load all standard files
   * await swe.loadStandardEphemeris();
   *
   * // Then use Swiss Ephemeris for calculations
   * const sun = swe.calculatePosition(jd, Planet.Sun, CalculationFlag.SwissEphemeris);
   */
  async loadStandardEphemeris(): Promise<void> {
    const CDN_BASE = 'https://cdn.jsdelivr.net/gh/aloistr/swisseph/ephe';
    await this.loadEphemerisFiles([
      { name: 'sepl_18.se1', url: `${CDN_BASE}/sepl_18.se1` },
      { name: 'semo_18.se1', url: `${CDN_BASE}/semo_18.se1` },
      { name: 'seas_18.se1', url: `${CDN_BASE}/seas_18.se1` },
    ]);
  }

  /**
   * Load Swiss Ephemeris data files from URLs
   *
   * Downloads ephemeris files and writes them to the virtual filesystem.
   * Use this for maximum precision calculations or custom file sources.
   *
   * @param files - Array of files to download with name and URL
   *
   * @example
   * // Load from custom CDN or server
   * await swe.loadEphemerisFiles([
   *   {
   *     name: 'sepl_18.se1',
   *     url: 'https://your-cdn.com/ephemeris/sepl_18.se1'
   *   },
   *   {
   *     name: 'semo_18.se1',
   *     url: 'https://your-cdn.com/ephemeris/semo_18.se1'
   *   }
   * ]);
   *
   * // Then use Swiss Ephemeris
   * const sun = swe.calculatePosition(jd, Planet.Sun, CalculationFlag.SwissEphemeris);
   */
  async loadEphemerisFiles(
    files: Array<{ name: string; url: string }>
  ): Promise<void> {
    this._checkReady();
    const m = this.module!;

    // Create ephemeris directory in virtual filesystem
    try {
      m.FS.mkdir('/ephemeris');
    } catch (e) {
      // Directory might already exist, ignore
    }

    // Download and write each file
    for (const file of files) {
      const response = await fetch(file.url);
      if (!response.ok) {
        throw new Error(`Failed to download ${file.name}: ${response.statusText}`);
      }

      const arrayBuffer = await response.arrayBuffer();
      const data = new Uint8Array(arrayBuffer);

      m.FS.writeFile(`/ephemeris/${file.name}`, data);
    }

    // Set ephemeris path to virtual directory
    this.setEphemerisPath('/ephemeris');
  }

  /**
   * Calculate Julian day number from calendar date
   *
   * @param year - Year (negative for BCE)
   * @param month - Month (1-12)
   * @param day - Day (1-31)
   * @param hour - Hour as decimal (0.0-23.999...)
   * @param calendarType - Calendar system (default: Gregorian)
   * @returns Julian day number
   *
   * @example
   * const jd = swe.julianDay(2007, 3, 3);
   * console.log(jd); // 2454162.5
   */
  julianDay(
    year: number,
    month: number,
    day: number,
    hour: number = 0,
    calendarType: CalendarType = CalendarType.Gregorian
  ): number {
    this._checkReady();

    // Validate inputs are valid numbers
    if (!Number.isFinite(year) || !Number.isFinite(month) || !Number.isFinite(day) || !Number.isFinite(hour)) {
      throw new TypeError(
        `julianDay requires finite numbers. Received: ` +
        `year=${year}, month=${month}, day=${day}, hour=${hour}`
      );
    }

    return this._julday(year, month, day, hour, calendarType);
  }

  /**
   * Calculate Julian day number from a JavaScript Date object
   *
   * Convenience function that converts a JavaScript Date to Julian day number.
   * The Date is interpreted as UTC.
   *
   * @param date - JavaScript Date object (interpreted as UTC)
   * @param calendarType - Calendar system (default: Gregorian)
   * @returns Julian day number
   *
   * @example
   * // From Date object
   * const date = new Date('1990-05-15T14:30:00Z');
   * const jd = swe.dateToJulianDay(date);
   *
   * // From timestamp
   * const now = new Date();
   * const jdNow = swe.dateToJulianDay(now);
   *
   * // Equivalent to swe.julianDay(1990, 5, 15, 14.5)
   * const jd2 = swe.dateToJulianDay(new Date(Date.UTC(1990, 4, 15, 14, 30)));
   */
  dateToJulianDay(
    date: Date,
    calendarType: CalendarType = CalendarType.Gregorian
  ): number {
    this._checkReady();

    // Validate that the date object is valid
    if (!(date instanceof Date)) {
      throw new TypeError('dateToJulianDay expects a Date object');
    }

    const year = date.getUTCFullYear();
    const month = date.getUTCMonth() + 1; // JavaScript months are 0-indexed
    const day = date.getUTCDate();
    const hours = date.getUTCHours();
    const minutes = date.getUTCMinutes();
    const seconds = date.getUTCSeconds();
    const milliseconds = date.getUTCMilliseconds();

    // Check if date is invalid (results in NaN)
    if (isNaN(year) || isNaN(month) || isNaN(day) || isNaN(hours)) {
      throw new TypeError(
        `Invalid Date object provided to dateToJulianDay. ` +
        `Date.toString() returned: "${date.toString()}". ` +
        `Please ensure the date is valid (e.g., avoid new Date("invalid")).`
      );
    }

    // Convert to decimal hours
    const decimalHours = hours + minutes / 60 + seconds / 3600 + milliseconds / 3600000;

    return this.julianDay(year, month, day, decimalHours, calendarType);
  }

  /**
   * Convert Julian day number to calendar date
   *
   * @param jd - Julian day number
   * @param calendarType - Calendar system (default: Gregorian)
   * @returns DateTime object
   *
   * @example
   * const date = swe.julianDayToDate(2454162.5);
   * console.log(date.toString());
   */
  julianDayToDate(
    jd: number,
    calendarType: CalendarType = CalendarType.Gregorian
  ): ExtendedDateTime {
    this._checkReady();

    const m = this.module!;
    const yearPtr = m._malloc(4);
    const monthPtr = m._malloc(4);
    const dayPtr = m._malloc(4);
    const hourPtr = m._malloc(8);

    m.ccall(
      'swe_revjul_wrap',
      null,
      ['number', 'number', 'number', 'number', 'number', 'number'],
      [jd, calendarType, yearPtr, monthPtr, dayPtr, hourPtr]
    );

    const year = m.getValue(yearPtr, 'i32');
    const month = m.getValue(monthPtr, 'i32');
    const day = m.getValue(dayPtr, 'i32');
    const hour = m.getValue(hourPtr, 'double');

    m._free(yearPtr);
    m._free(monthPtr);
    m._free(dayPtr);
    m._free(hourPtr);

    return new DateTimeImpl(year, month, day, hour, calendarType);
  }

  /**
   * Calculate planetary positions
   *
   * Note: Browser version uses Moshier ephemeris by default.
   *
   * @param julianDay - Julian day number in Universal Time
   * @param body - Celestial body to calculate
   * @param flags - Calculation flags (default: Moshier with speed)
   * @returns PlanetaryPosition object
   *
   * @example
   * const sun = swe.calculatePosition(jd, Planet.Sun);
   * console.log(`Sun: ${sun.longitude}°, ${sun.latitude}°`);
   *
   * const moon = swe.calculatePosition(
   *   jd,
   *   Planet.Moon,
   *   CalculationFlag.MoshierEphemeris | CalculationFlag.Speed
   * );
   */
  calculatePosition(
    julianDay: number,
    body: CelestialBody,
    flags: CalculationFlagInput = CommonCalculationFlags.DefaultMoshier
  ): PlanetaryPosition {
    this._checkReady();

    const normalizedFlags = normalizeFlags(flags);
    const m = this.module!;
    const xxPtr = m._malloc(6 * 8); // 6 doubles
    const serrPtr = m._malloc(256);

    const retflag = m.ccall(
      'swe_calc_ut_wrap',
      'number',
      ['number', 'number', 'number', 'number', 'number'],
      [julianDay, body, normalizedFlags, xxPtr, serrPtr]
    );

    if (retflag < 0) {
      const error = m.UTF8ToString(serrPtr);
      m._free(xxPtr);
      m._free(serrPtr);
      throw new Error(error);
    }

    const xx: number[] = [];
    for (let i = 0; i < 6; i++) {
      xx[i] = m.getValue(xxPtr + i * 8, 'double');
    }

    m._free(xxPtr);
    m._free(serrPtr);

    return {
      longitude: xx[0],
      latitude: xx[1],
      distance: xx[2],
      longitudeSpeed: xx[3],
      latitudeSpeed: xx[4],
      distanceSpeed: xx[5],
      flags: retflag,
    };
  }

  /**
   * Get celestial body name
   *
   * @param body - Celestial body identifier
   * @returns Name as a string
   *
   * @example
   * const name = swe.getCelestialBodyName(Planet.Mars);
   * console.log(name); // "Mars"
   */
  getCelestialBodyName(body: CelestialBody): string {
    this._checkReady();
    return this._getPlanetName(body);
  }

  /** Set the ayanamsa system used for sidereal calculations. */
  setSiderealMode(
    siderealMode: number,
    t0: number = 0,
    ayanT0: number = 0
  ): void {
    this._checkReady();
    this._setSiderealMode(siderealMode, t0, ayanT0);
  }

  /** Get the ayanamsa for a Julian Day in Universal Time. */
  getAyanamsa(julianDay: number): number {
    this._checkReady();
    return this._getAyanamsa(julianDay);
  }

  /** Get the ayanamsa using explicit calculation flags. */
  getAyanamsaExUt(
    julianDay: number,
    flags: CalculationFlagInput = CalculationFlag.SwissEphemeris
  ): number {
    this._checkReady();

    const normalizedFlags = normalizeFlags(flags);
    const m = this.module!;
    const ayanamsaPtr = m._malloc(8);
    const serrPtr = m._malloc(256);

    try {
      const retflag = m.ccall(
        'swe_get_ayanamsa_ex_ut_wrap',
        'number',
        ['number', 'number', 'number', 'number'],
        [julianDay, normalizedFlags, ayanamsaPtr, serrPtr]
      );

      if (retflag < 0) {
        const error = m.UTF8ToString(serrPtr);
        throw new Error(error || 'Failed to calculate ayanamsa');
      }

      return m.getValue(ayanamsaPtr, 'double');
    } finally {
      m._free(ayanamsaPtr);
      m._free(serrPtr);
    }
  }

  /**
   * Find next lunar eclipse
   *
   * @param startJulianDay - Julian day to start search from
   * @param flags - Calculation flags (default: Moshier)
   * @param eclipseType - Filter by eclipse type (0 = all types)
   * @param backward - Search backward in time if true
   * @returns LunarEclipse object
   *
   * @example
   * const eclipse = swe.findNextLunarEclipse(jd);
   * console.log(`Is total: ${eclipse.isTotal()}`);
   * console.log(`Duration: ${eclipse.getTotalityDuration()} hours`);
   */
  findNextLunarEclipse(
    startJulianDay: number,
    flags: CalculationFlagInput = CalculationFlag.MoshierEphemeris,
    eclipseType: EclipseTypeFlagInput = 0,
    backward: boolean = false
  ): LunarEclipse {
    this._checkReady();

    const normalizedFlags = normalizeFlags(flags);
    const normalizedEclipseType = normalizeEclipseTypes(eclipseType);
    const m = this.module!;
    const tretPtr = m._malloc(10 * 8); // 10 doubles
    const serrPtr = m._malloc(256);

    const retflag = m.ccall(
      'swe_lun_eclipse_when_wrap',
      'number',
      ['number', 'number', 'number', 'number', 'number', 'number'],
      [startJulianDay, normalizedFlags, normalizedEclipseType, tretPtr, backward ? 1 : 0, serrPtr]
    );

    if (retflag < 0) {
      const error = m.UTF8ToString(serrPtr);
      m._free(tretPtr);
      m._free(serrPtr);
      throw new Error(error);
    }

    const tret: number[] = [];
    for (let i = 0; i < 10; i++) {
      tret[i] = m.getValue(tretPtr + i * 8, 'double');
    }

    m._free(tretPtr);
    m._free(serrPtr);

    return new LunarEclipseImpl(
      retflag,
      tret[0], // maximum
      tret[2], // partial begin
      tret[3], // partial end
      tret[4], // total begin
      tret[5], // total end
      tret[6], // penumbral begin
      tret[7]  // penumbral end
    );
  }

  /**
   * Find next solar eclipse globally
   *
   * @param startJulianDay - Julian day to start search from
   * @param flags - Calculation flags (default: Moshier)
   * @param eclipseType - Filter by eclipse type (0 = all types)
   * @param backward - Search backward in time if true
   * @returns SolarEclipse object
   *
   * @example
   * const eclipse = swe.findNextSolarEclipse(jd);
   * console.log(`Is total: ${eclipse.isTotal()}`);
   * console.log(`Is central: ${eclipse.isCentral()}`);
   */
  findNextSolarEclipse(
    startJulianDay: number,
    flags: CalculationFlagInput = CalculationFlag.MoshierEphemeris,
    eclipseType: EclipseTypeFlagInput = 0,
    backward: boolean = false
  ): SolarEclipse {
    this._checkReady();

    const normalizedFlags = normalizeFlags(flags);
    const normalizedEclipseType = normalizeEclipseTypes(eclipseType);
    const m = this.module!;
    const tretPtr = m._malloc(10 * 8);
    const serrPtr = m._malloc(256);

    const retflag = m.ccall(
      'swe_sol_eclipse_when_glob_wrap',
      'number',
      ['number', 'number', 'number', 'number', 'number', 'number'],
      [startJulianDay, normalizedFlags, normalizedEclipseType, tretPtr, backward ? 1 : 0, serrPtr]
    );

    if (retflag < 0) {
      const error = m.UTF8ToString(serrPtr);
      m._free(tretPtr);
      m._free(serrPtr);
      throw new Error(error);
    }

    const tret: number[] = [];
    for (let i = 0; i < 10; i++) {
      tret[i] = m.getValue(tretPtr + i * 8, 'double');
    }

    m._free(tretPtr);
    m._free(serrPtr);

    return new SolarEclipseImpl(
      retflag,
      tret[0], // maximum
      tret[2], // partial begin
      tret[3], // partial end
      tret[4], // central begin
      tret[5], // central end
      tret[6], // center line begin
      tret[7]  // center line end
    );
  }

  // ─── Local eclipse circumstances ─────────────────────────────────────────

  /** Allocates double arrays (and an error buffer) for one C call, and frees them after. */
  private _withDoubles<T>(sizes: number[], run: (ptrs: number[], serr: number) => T): T {
    const m = this.module!;
    const ptrs = sizes.map((n) => m._malloc(n * 8));
    const serr = m._malloc(256);
    try {
      return run(ptrs, serr);
    } finally {
      ptrs.forEach((p) => m._free(p));
      m._free(serr);
    }
  }

  private _readDoubles(ptr: number, n: number): number[] {
    const m = this.module!;
    return Array.from({ length: n }, (_, i) => m.getValue(ptr + i * 8, 'double'));
  }

  private _writeDoubles(ptr: number, values: number[]): void {
    const m = this.module!;
    values.forEach((v, i) => m.setValue(ptr + i * 8, v, 'double'));
  }

  private _place(ptr: number, place?: GeoPosition): void {
    this._writeDoubles(ptr, [place?.longitude ?? 0, place?.latitude ?? 0, place?.altitude ?? 0]);
  }

  /**
   * Set the observer's place for topocentric positions (CalculationFlag.Topocentric)
   *
   * @param longitude - Geographic longitude, east positive
   * @param latitude - Geographic latitude, north positive
   * @param altitude - Altitude above sea level in metres
   */
  setTopocentric(longitude: number, latitude: number, altitude: number = 0): void {
    this._checkReady();
    this.module!.ccall('swe_set_topo_wrap', null, ['number', 'number', 'number'], [longitude, latitude, altitude]);
  }

  /**
   * Find where on Earth a solar eclipse is central at a given moment
   *
   * Sample it over the eclipse to trace the central line. For a non-central eclipse the
   * position is where the eclipse is greatest.
   *
   * @example
   * const e = swe.findNextSolarEclipse(swe.julianDay(2027, 7, 1));
   * const at = swe.solarEclipseWhere(e.maximum);
   * console.log(at.longitude, at.latitude, at.attributes.sarosSeries);
   */
  solarEclipseWhere(julianDay: number, flags: CalculationFlagInput = CalculationFlag.MoshierEphemeris): SolarEclipseWhere {
    this._checkReady();
    const m = this.module!;
    return this._withDoubles([10, 20], ([geo, attr], serr) => {
      const type = m.ccall('swe_sol_eclipse_where_wrap', 'number', ['number', 'number', 'number', 'number', 'number'], [julianDay, normalizeFlags(flags), geo, attr, serr]);
      if (type < 0) throw new Error(m.UTF8ToString(serr));
      const [longitude, latitude] = this._readDoubles(geo, 2);
      return { type, longitude, latitude, attributes: solarEclipseAttributes(this._readDoubles(attr, 20)) };
    });
  }

  /**
   * How a solar eclipse looks from a place at a given moment
   *
   * @returns type 0 when the Sun is not eclipsed there and then
   */
  solarEclipseHow(
    julianDay: number,
    place: GeoPosition,
    flags: CalculationFlagInput = CalculationFlag.MoshierEphemeris
  ): { type: number; attributes: SolarEclipseAttributes } {
    this._checkReady();
    const m = this.module!;
    return this._withDoubles([3, 20], ([geo, attr], serr) => {
      this._place(geo, place);
      const type = m.ccall('swe_sol_eclipse_how_wrap', 'number', ['number', 'number', 'number', 'number', 'number'], [julianDay, normalizeFlags(flags), geo, attr, serr]);
      if (type < 0) throw new Error(m.UTF8ToString(serr));
      return { type, attributes: solarEclipseAttributes(this._readDoubles(attr, 20)) };
    });
  }

  /**
   * Find the next solar eclipse visible from a place
   *
   * @example
   * // The 2027 eclipse from Luxor
   * const e = swe.findNextSolarEclipseAt(swe.julianDay(2027, 7, 1), { longitude: 32.64, latitude: 25.69 });
   * console.log(e.isTotal(), e.centralDuration()); // true, ~381 s
   */
  findNextSolarEclipseAt(
    startJulianDay: number,
    place: GeoPosition,
    flags: CalculationFlagInput = CalculationFlag.MoshierEphemeris,
    backward: boolean = false
  ): LocalSolarEclipse {
    this._checkReady();
    const m = this.module!;
    return this._withDoubles([3, 10, 20], ([geo, tret, attr], serr) => {
      this._place(geo, place);
      const type = m.ccall(
        'swe_sol_eclipse_when_loc_wrap',
        'number',
        ['number', 'number', 'number', 'number', 'number', 'number', 'number'],
        [startJulianDay, normalizeFlags(flags), geo, tret, attr, backward ? 1 : 0, serr]
      );
      if (type < 0) throw new Error(m.UTF8ToString(serr));
      return localSolarEclipse(type, this._readDoubles(tret, 10), this._readDoubles(attr, 20));
    });
  }

  /**
   * How a lunar eclipse looks at a moment; with a place, also where the Moon stands in its sky
   */
  lunarEclipseHow(
    julianDay: number,
    place?: GeoPosition,
    flags: CalculationFlagInput = CalculationFlag.MoshierEphemeris
  ): { type: number; attributes: LunarEclipseAttributes } {
    this._checkReady();
    const m = this.module!;
    return this._withDoubles([3, 20], ([geo, attr], serr) => {
      this._place(geo, place);
      const type = m.ccall('swe_lun_eclipse_how_wrap', 'number', ['number', 'number', 'number', 'number', 'number'], [julianDay, normalizeFlags(flags), geo, attr, serr]);
      if (type < 0) throw new Error(m.UTF8ToString(serr));
      return { type, attributes: lunarEclipseAttributes(this._readDoubles(attr, 20)) };
    });
  }

  /**
   * Find the next lunar eclipse visible from a place
   */
  findNextLunarEclipseAt(
    startJulianDay: number,
    place: GeoPosition,
    flags: CalculationFlagInput = CalculationFlag.MoshierEphemeris,
    backward: boolean = false
  ): LocalLunarEclipse {
    this._checkReady();
    const m = this.module!;
    return this._withDoubles([3, 10, 20], ([geo, tret, attr], serr) => {
      this._place(geo, place);
      const type = m.ccall(
        'swe_lun_eclipse_when_loc_wrap',
        'number',
        ['number', 'number', 'number', 'number', 'number', 'number', 'number'],
        [startJulianDay, normalizeFlags(flags), geo, tret, attr, backward ? 1 : 0, serr]
      );
      if (type < 0) throw new Error(m.UTF8ToString(serr));
      return localLunarEclipse(type, this._readDoubles(tret, 10), this._readDoubles(attr, 20));
    });
  }

  /**
   * Turn ecliptic or equatorial coordinates into azimuth and altitude for a place
   *
   * @param coordinates - [longitude or right ascension, latitude or declination, distance] in degrees and AU
   * @param equatorial - true if the coordinates are right ascension and declination
   * @param pressure - atmospheric pressure in mbar for refraction (0 estimates it from the altitude)
   * @param temperature - in °C, for refraction
   */
  horizontalCoordinates(
    julianDay: number,
    place: GeoPosition,
    coordinates: [number, number, number],
    equatorial: boolean = false,
    pressure: number = 0,
    temperature: number = 10
  ): HorizontalCoordinates {
    this._checkReady();
    const m = this.module!;
    return this._withDoubles([3, 3, 3], ([geo, xin, xaz]) => {
      this._place(geo, place);
      this._writeDoubles(xin, coordinates);
      m.ccall(
        'swe_azalt_wrap',
        null,
        ['number', 'number', 'number', 'number', 'number', 'number', 'number'],
        [julianDay, equatorial ? 1 : 0, geo, pressure, temperature, xin, xaz]
      );
      const [az, altitude, apparentAltitude] = this._readDoubles(xaz, 3);
      return { azimuth: compassBearing(az), altitude, apparentAltitude };
    });
  }

  /**
   * Greenwich apparent sidereal time, in hours
   */
  siderealTime(julianDay: number): number {
    this._checkReady();
    return this.module!.ccall('swe_sidtime_wrap', 'number', ['number'], [julianDay]);
  }

  /**
   * Calculate house cusps and angles
   *
   * @param julianDay - Julian day number in Universal Time
   * @param latitude - Geographic latitude
   * @param longitude - Geographic longitude
   * @param houseSystem - House system (default: Placidus)
   * @returns HouseData object
   *
   * @example
   * const houses = swe.calculateHouses(jd, 40.7128, -74.0060);
   * console.log(`Ascendant: ${houses.ascendant}°`);
   * console.log(`MC: ${houses.mc}°`);
   */
  calculateHouses(
    julianDay: number,
    latitude: number,
    longitude: number,
    houseSystem: HouseSystem = HouseSystem.Placidus
  ): HouseData {
    this._checkReady();

    const m = this.module!;
    const cuspsPtr = m._malloc(13 * 8);
    const ascmcPtr = m._malloc(10 * 8);

    const hsysCode = houseSystem.charCodeAt(0);

    m.ccall(
      'swe_houses_wrap',
      'number',
      ['number', 'number', 'number', 'number', 'number', 'number'],
      [julianDay, latitude, longitude, hsysCode, cuspsPtr, ascmcPtr]
    );

    const cusps: number[] = [];
    for (let i = 0; i < 13; i++) {
      cusps[i] = m.getValue(cuspsPtr + i * 8, 'double');
    }

    const ascmc: number[] = [];
    for (let i = 0; i < 10; i++) {
      ascmc[i] = m.getValue(ascmcPtr + i * 8, 'double');
    }

    m._free(cuspsPtr);
    m._free(ascmcPtr);

    return {
      cusps,
      ascendant: ascmc[HousePoint.Ascendant],
      mc: ascmc[HousePoint.MC],
      armc: ascmc[HousePoint.ARMC],
      vertex: ascmc[HousePoint.Vertex],
      equatorialAscendant: ascmc[HousePoint.EquatorialAscendant],
      coAscendant1: ascmc[HousePoint.CoAscendant1],
      coAscendant2: ascmc[HousePoint.CoAscendant2],
      polarAscendant: ascmc[HousePoint.PolarAscendant],
      houseSystem,
    };
  }

  /**
   * Close Swiss Ephemeris and free resources
   */
  close(): void {
    if (this.ready) {
      this._close();
    }
  }
}

// Export all types
export * from '@swisseph/core';

// Export singleton instance for convenience
export const swisseph = new SwissEphemeris();

// Default export for backwards compatibility
export default SwissEphemeris;

// Browser global compatibility
declare global {
  interface Window {
    SwissEphemeris?: typeof SwissEphemeris;
    swisseph?: SwissEphemeris;
  }
}

if (typeof window !== 'undefined') {
  window.SwissEphemeris = SwissEphemeris;
  window.swisseph = swisseph;
}
